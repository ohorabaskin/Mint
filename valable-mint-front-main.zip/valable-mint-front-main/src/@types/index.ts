export interface GachaItemType {
  TID?: number;
  Name?: string;
  InfoType?: string;
  Grade?: string;
  attribute?: Attribute;
  ThumbnailImagePath?: string;
  ImagePath?: string;
  CardImagePath: string;
}

export interface GachaItemDetail {
  TID: number;
  Name: string;
  InfoType: string;
  Grade: string;
  Attribute1Name: string;
  Attribute1Value: string;
  Attribute2Name: string;
  Attribute2Value: string;
  Attribute3Name: string;
  Attribute3Value: string;
  Attribute4Name: string;
  Attribute4Value: string;
  Attribute5Name: string;
  Attribute5Value: string;
  Attribute6Name: string;
  Attribute6Value: string;
  ThumbnailImagePath: string;
  ImagePath: string;
  CardImagePath: string;
}

export interface UserType {
  id: string;
  socialId: string;
  email: string;
  nickName: string;
  name: string;
  phone: string;
  provider: string;
  walletAccount: string;
  role: string;
  currentHashedRefreshToken: string;
  lastLoginTime: string;
  connAvailableTime: string;
  jwtid: string;
  tokenList: tokenType[];
  loginType: string;
}

export interface MeType {
  id: string;
  socialId: string;
  email: string;
  nickName: string;
  name: string;
  phone: string;
  provider: string;
  walletAccount: string;
  role: string;
  currentHashedRefreshToken: string;
  lastLoginTime: string;
  connAvailableTime: any;
  jwtid: string;
}

export interface tokenType {
  contractAddress: string;
  amount: string;
  symbol: string;
  name: string;
  chain: string;
  symbolUrl: string;
  chainUrl: string;
  price?: string;
}

export interface Attribute {
  'ATK SPD': string;
  'MAX Melee ATK': string;
}

export interface ListItemType {
  id: number;
  createdAt: string;
  updatedAt: string;
  TID: number;
  GachaType: number;
  GachaGrade: number;
  userId: string;
  nftInfoMetaData: NftInfoMetaData;
  nftInfoMetaDataId: number;
}

export interface NftInfoMetaData {
  ThumbnailImagePath: string;
  ImagePath: string;
  CardImagePath: string;
  Name?: string;
}

export interface GachaItemListType {
  items: ListItemType[];
  pageTotal: number;
  total: number;
}
