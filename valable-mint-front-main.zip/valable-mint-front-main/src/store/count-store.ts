import { api } from 'api';
import { create } from 'zustand';
import { combine } from 'zustand/middleware';

const initialState: {
  count: [{ Transform: number }, { MagicDoll: number }];
} = {
  count: [{ Transform: 0 }, { MagicDoll: 0 }],
};

export const useCountStore = create(
  combine(initialState, (set) => ({
    getCnt: async () => {
      try {
        const { data } = await api.get('/api/gacha/inventory/type-count');
        set({ count: data });
        return data;
      } catch (error) {
        set({ count: [{ Transform: 0 }, { MagicDoll: 0 }] });
      }
    },
    resetCnt: () => {
      set({
        count: [{ Transform: 0 }, { MagicDoll: 0 }],
      });
    },
  })),
);
