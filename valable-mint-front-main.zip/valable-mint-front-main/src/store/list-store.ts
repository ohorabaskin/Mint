import { GachaItemListType } from '@types';
import { api } from 'api';
import { create } from 'zustand';
import { combine } from 'zustand/middleware';

export enum GachaType {
  all = '',
  Transform = 'Transform',
  MagicDoll = 'MagicDoll',
}

export enum SortType {
  none = '',
  createdAtDesc = 'createdAt.desc',
  createdAtAsc = 'createdAt.asc',
  gradeDesc = 'grade.desc',
  gradeAsc = 'grade.asc',
}

interface ListState {
  list: GachaItemListType;
  sortBy: SortType;
  gachaType: GachaType;
  page: number;
}

const initialState: ListState = {
  list: { items: [], pageTotal: 0, total: 0 },
  gachaType: GachaType.all,
  sortBy: SortType.none,
  page: 1,
};

export const useListStore = create(
  combine(initialState, (set, state) => ({
    setList: (list: GachaItemListType) => {
      set(() => ({
        list,
      }));
    },

    setGachaType: (gachaType: GachaType) => {
      set(() => ({
        gachaType,
      }));
    },

    setSortBy: (sortBy: SortType) => {
      set(() => ({
        sortBy,
      }));
    },

    setPage: (page: number) => {
      set(() => ({
        page,
      }));
    },

    getList: async (page?: number) => {
      try {
        let paramsPage = page ? page : state().page + 1;
        let url = `/api/gacha/inventory?page=${paramsPage}`;
        if (state().gachaType) {
          url = url + '&gachaType=' + state().gachaType;
        }

        if (state().sortBy) {
          url = url + '&sortBy=' + state().sortBy;
        }
        const { data } = await api.get(url);

        const result = {
          items: paramsPage === 1 ? data.items : state().list.items.concat(data.items),
          pageTotal: data.pageTotal,
          total: data.total,
        };

        set({ list: result, page: paramsPage });
      } catch (error) {
        set({ list: { items: [], pageTotal: 0, total: 0 } });
      }
    },

    reset: async (props?: { gacha: GachaType; sort: SortType }) => {
      try {
        let url = `/api/gacha/inventory?page=1`;
        if (props) {
          if (props.gacha) {
            url = url + '&gachaType=' + props.gacha;
          }

          if (props.sort) {
            url = url + '&sortBy=' + props.sort;
          }
        }
        const { data } = await api.get(url);

        set({
          list: data,
          page: 1,
          gachaType: props?.gacha || GachaType.all,
          sortBy: props?.sort || SortType.none,
        });
      } catch (error) {
        set({
          list: { items: [], pageTotal: 0, total: 0 },
          gachaType: props?.gacha || GachaType.all,
          sortBy: props?.sort || SortType.none,
        });
      }
    },

    resetFilter: () => {
      set(() => ({
        page: 1,
        gachaType: GachaType.all,
        sortBy: SortType.none,
      }));
    },
  })),
);
