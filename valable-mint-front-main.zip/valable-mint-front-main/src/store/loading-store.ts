import { create } from 'zustand';
import { combine } from 'zustand/middleware';

const initialState: {
  loading: boolean;
} = {
  loading: false,
};

export const useLoadingStore = create(
  combine(initialState, (set) => ({
    closePopup: () => {
      set(() => ({
        loading: false,
      }));
    },
    showPopup: () => {
      set(() => ({
        loading: true,
      }));
    },
  })),
);

export const loadingStart = () => {
  useLoadingStore.setState({
    loading: true,
  });
};

export const loadingEnd = () => {
  useLoadingStore.setState(initialState);
};
