import { create } from 'zustand';
import { combine } from 'zustand/middleware';

interface PopupProps {
  confirm?: any;
  repeatCnt?: number;
}

const initialState: {
  visible: boolean;
  close?: () => void;
  confirm?: any;
} = {
  visible: false,
};

export const usePasswordStore = create(
  combine(initialState, (set) => ({
    closePopup: () => {
      set(() => ({
        visible: false,
      }));
    },
    showPopup: (item: PopupProps) => {
      set(() => ({
        visible: true,
        confirm: (p: string) => item.confirm(p),
        repeatCnt: item.repeatCnt,
      }));
    },
  })),
);

export const showPasswordCommonPopup = (item: PopupProps) => {
  usePasswordStore.setState({
    visible: true,
    confirm: async (pass: string) => await item.confirm(pass),
  });
};

export const closePasswordCommonPopup = () => {
  usePasswordStore.setState(initialState);
};
