import { UserType, tokenType } from '@types';
import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';

const initUserData = {
  id: '',
  socialId: '',
  email: '',
  nickName: '',
  name: '',
  phone: '',
  provider: '',
  walletAccount: '',
  role: '',
  currentHashedRefreshToken: '',
  lastLoginTime: '',
  connAvailableTime: '',
  jwtid: '',
  tokenList: [],
  loginType: '',
};

const initialState: {
  Authentication: string;
  user: UserType;
} = {
  Authentication: '',
  user: initUserData,
};

type StoreState = typeof initialState;

interface StoreType extends StoreState {
  setUser: (user: UserType) => void;
  setToken: (token: string) => void;
  removeUser: () => void;
  removeToken: () => void;
  updateToken: (tokenList: tokenType[]) => void;
}

const useUserStore = create<
  StoreType,
  [['zustand/devtools', never], ['zustand/persist', StoreState]]
>(
  devtools(
    persist(
      (set) => ({
        ...initialState,
        setToken: (token) =>
          set((state) => {
            return {
              ...state,
              Authentication: token,
            };
          }),
        removeToken: () =>
          set((state) => {
            return {
              ...state,
              Authentication: '',
            };
          }),
        setUser: (user) =>
          set((state) => {
            return {
              ...state,
              user,
            };
          }),
        removeUser: () =>
          set((state) => {
            return {
              ...state,
              user: initUserData,
            };
          }),
        updateToken: (tokenList) =>
          set((state) => {
            return {
              ...state,
              user: {
                ...state.user,
                tokenList,
              },
            };
          }),
      }),
      {
        name: 'store',
      },
    ),
  ),
);

export default useUserStore;
