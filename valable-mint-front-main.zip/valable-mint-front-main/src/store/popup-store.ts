import { create } from 'zustand';
import { combine } from 'zustand/middleware';

interface PopupProps {
  title: string;
  desc?: string;
  closeText?: string;
  close?: () => void;
  confirm?: () => void;
  confirmText?: string;
}

const initialState: {
  visible: boolean;
  info: PopupProps;
} = {
  visible: false,
  info: {
    title: '',
  },
};

export const usePopupStore = create(
  combine(initialState, (set) => ({
    closePopup: () => {
      set(() => ({
        ...initialState,
        visible: false,
      }));
    },
    showPopup: (item: PopupProps) => {
      set(() => ({
        visible: true,
        info: item,
      }));
    },
  })),
);

export const showCommonPopup = (item: PopupProps) => {
  usePopupStore.setState({
    visible: true,
    info: item,
  });
};

export const closeCommonPopup = () => {
  usePopupStore.setState(initialState);
};
