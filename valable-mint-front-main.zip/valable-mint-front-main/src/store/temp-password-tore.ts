import { create } from 'zustand';
import { combine } from 'zustand/middleware';

const initialState: {
  password: string;
} = {
  password: '',
};

const useTempStore = create(
  combine(initialState, (set) => ({
    resetPassword: () => {
      set(() => ({
        password: '',
      }));
    },
    setPassword: (password: string) => {
      set(() => ({
        password,
      }));
    },
  })),
);

export default useTempStore;
