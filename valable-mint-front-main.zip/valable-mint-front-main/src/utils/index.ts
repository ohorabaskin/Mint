import { GachaItemType } from '@types';
import BigNumber from 'bignumber.js';
import { SortType } from 'store/list-store';

export const baseApiUrl = import.meta.env.VITE_API_URL;

export const addressParse = (str: string) =>
  str.length > 6 ? str.slice(0, 3) + '.......' + str.slice(-3) : str;

export const priceParse = (str: string) => {
  if (str.split('.')[1]) {
    return str.split('.')[0] + '.' + str.split('.')[1].substring(0, 3);
  }
  return str.split('.')[0];
};

export const screenFixed = () => {
  document.querySelector('html')?.classList.remove('over-auto');
  document.querySelector('html')?.classList.add('over-hidden');
};
export const screenAuto = () => {
  document.querySelector('html')?.classList.remove('over-hidden');
  document.querySelector('html')?.classList.add('over-auto');
};

export const convertGachaGradeText = (grad: number) => {
  if (grad === 1) return 'Common';
  if (grad === 2) return 'Premium';
  if (grad === 3) return 'Rare';
  if (grad === 4) return 'Epic';
  if (grad === 5) return 'Legendary';
  if (grad === 6) return 'Mythic';
};

export const compareDecimalNumbers = (num1: string, num2: string, repeatCount: number) => {
  const bigNum1 = new BigNumber(num1).times(repeatCount);
  const bigNum2 = new BigNumber(num2);
  return bigNum1.gt(bigNum2);
};

export const initImgList: GachaItemType[] = [
  {
    CardImagePath: '',
    Grade: '',
  },
  {
    CardImagePath: '',
    Grade: '',
  },
  {
    CardImagePath: '',
    Grade: '',
  },
  {
    CardImagePath: '',
    Grade: '',
  },
  {
    CardImagePath: '',
    Grade: '',
  },
];

export const fillCard = (value: number) => {
  return Array(value * 5)
    .fill('')
    .map((_) => {
      return {
        CardImagePath: '',
        Grade: '',
      };
    });
};

export const convertSortText = (sort: SortType) => {
  if (sort === SortType.gradeAsc) {
    return '등급 오름 차순';
  }
  if (sort === SortType.gradeDesc) {
    return '등급 내림 차순';
  }
  if (sort === SortType.createdAtAsc) {
    return '시간별 오름 차순';
  }
  if (sort === SortType.createdAtDesc) {
    return '시간별 내림 차순';
  }
};
