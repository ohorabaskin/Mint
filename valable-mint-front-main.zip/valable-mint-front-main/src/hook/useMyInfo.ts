import { MeType, tokenType } from '@types';
import { api } from 'api';
import useUserStore from 'store/user-store';

const useMyInfo = () => {
  const { setUser, user, updateToken } = useUserStore();

  const getMeInfo = async () => {
    const { data } = await api.get<MeType>('/api/user/me');
    return data;
  };

  const getTokenList = async () => {
    const {
      data: { items },
    } = await api.post<{ items: tokenType[] }>('/api/token', {
      chain: 'polygon',
    });
    return items;
  };

  const setMyInfo = async (authType: string) => {
    try {
      const me = await getMeInfo();
      const tokenList = await getTokenList();

      const info = {
        ...me,
        tokenList,
        loginType: authType,
      };

      setUser(info);
    } catch (err) {
      throw err;
    }
  };

  const updateInfo = async () => {
    const tokenList = await getTokenList();
    updateToken(tokenList);
  };

  return { setMyInfo, user, getTokenList, updateInfo };
};

export default useMyInfo;
