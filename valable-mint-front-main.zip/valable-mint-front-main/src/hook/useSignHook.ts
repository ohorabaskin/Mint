import { api } from 'api';
import useMyInfo from './useMyInfo';
import { showCommonPopup } from 'store/popup-store';
import useTempStore from 'store/temp-password-tore';
import useUserStore from 'store/user-store';
import { useListStore } from 'store/list-store';

const tokenEndpoint = 'https://appleid.apple.com/auth/token'; // Apple 로그인 API의 토큰 엔드포인트
export const useSignHook = () => {
  const { setToken, user, removeToken, removeUser } = useUserStore();
  const { setMyInfo } = useMyInfo();
  const { resetPassword } = useTempStore();
  const { resetFilter } = useListStore();

  const logout = () => {
    removeToken();
    removeUser();
    resetPassword();
    resetFilter();
  };

  const loginType = (() => user.loginType)();

  const snsLogin = async (user: { _token: { accessToken: string } }, authType: string) => {
    try {
      const access_token = user._token.accessToken;
      const query = `access_token=${encodeURIComponent(access_token)}`;
      const response = await api.get(`/api/auth/${authType}/token?${query}`, {
        headers: {
          'Content-Type': 'application/json',
          'X-VALABLE-VERSION': '1',
        },
      });

      setToken(`Bearer ${response?.data.Authentication}`);

      await setMyInfo(authType);
    } catch (e: any) {
      showCommonPopup({ title: e.response.data.message, closeText: '닫기' });
    }
  };

  const appleLogin = async () => {
    const url = new URL(window.location.href);
    const code = url.searchParams.get('code');
    if (code) {
      try {
        const { data } = await api.post(tokenEndpoint, {
          grant_type: 'authorization_code',
          code: code,
          redirect_uri: 'https://home-dev.itsbloc.com',
          client_id: 'io.itsbloc.wallet.serviceid',
          client_secret: '',
        });
        const access_token = data.access_token;
        const query = `access_token=${encodeURIComponent(access_token)}`;
        const response = await api.get(`/api/auth/apple/token?${query}`, {
          headers: {
            'Content-Type': 'application/json',
            'X-VALABLE-VERSION': '1',
          },
        });

        setToken(`Bearer ${response?.data.Authentication}`);

        await setMyInfo('apple');
      } catch (e) {
      } finally {
        window.location.replace('/');
      }
    }
  };

  return { snsLogin, loginType, logout, appleLogin };
};
