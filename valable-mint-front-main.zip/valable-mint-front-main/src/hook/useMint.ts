import { api } from 'api';
import { compareDecimalNumbers } from 'utils';
import useMyInfo from './useMyInfo';
import { closeCommonPopup, showCommonPopup } from 'store/popup-store';
import useTempStore from 'store/temp-password-tore';
import { closePasswordCommonPopup, showPasswordCommonPopup } from 'store/password-store';

export const useMint = () => {
  const { password, setPassword } = useTempStore();
  const { getTokenList, updateInfo } = useMyInfo();

  const getMintInfo = async () => {
    try {
      const { data } = await api.get<{ mintPrice: string }>('/api/gacha/mint-info');
      return data.mintPrice;
    } catch (error) {
      throw error;
    }
  };

  const getMintLimit = async () => {
    try {
      const { data } = await api.get<{ mintPrice: string }>('/api/gacha/mint-limit');
      return data;
    } catch (error) {
      throw error;
    }
  };

  const canMint = async (mintingPrice: string): Promise<boolean> => {
    try {
      const tokenList = await getTokenList();
      const poeTokenAmount = tokenList.find((i) => i.symbol === 'PED')?.amount || '0';
      return compareDecimalNumbers(poeTokenAmount, mintingPrice, 1);
    } catch (error) {
      throw error;
    }
  };

  const cardMint = async (id: number, password: string, callback?: () => void) => {
    try {
      const result = await api.post(`/api/gacha/nft-mint/${id}`, {
        signPass: password,
      });
      callback && callback();
      closePasswordCommonPopup();
      showCommonPopup({
        title: '민팅에 성공 하였습니다. \n 10분 후 APP에서 확인해주세요.',
        closeText: '확인',
      });
      return result;
    } catch (err: any) {
      showCommonPopup({ title: err.response.data.message, closeText: '확인' });
      throw err;
    } finally {
      updateInfo();
    }
  };

  const minitnig = async (id: number, callback?: () => void) => {
    const mintingPrice = await getMintInfo();
    const canMintItem = await canMint(mintingPrice);
    if (canMintItem) {
      mintingPopup(password, id, mintingPrice, callback);
    } else {
      showCommonPopup({ title: 'PED가 부족 합니다. \n PED를 충전해주세요.', closeText: '닫기' });
    }
  };

  const mintingPopup = (pass: string, id: number, mintingPrice: string, callback?: () => void) => {
    showCommonPopup({
      title: '민팅을 진행 하시겠습니까?',
      desc: '가격: ' + Math.floor(parseFloat(mintingPrice) * 100) / 100 + ' PED',
      closeText: '취소',
      confirm: async () => {
        if (pass) {
          await cardMint(id, pass, callback);
        } else {
          closeCommonPopup();
          showPasswordCommonPopup({
            confirm: async (p: string) => {
              await cardMint(id, p, callback);
              setPassword(p);
            },
          });
        }
      },
      confirmText: '민팅',
    });
  };
  return {
    cardMint,
    getMintInfo,
    canMint,
    minitnig,
    getMintLimit,
  };
};
