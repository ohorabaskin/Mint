import { GachaItemDetail, GachaItemType } from '@types';
import { api } from 'api';
import useMyInfo from './useMyInfo';
import { compareDecimalNumbers } from 'utils';
import { closeCommonPopup, showCommonPopup } from 'store/popup-store';
import useTempStore from 'store/temp-password-tore';
import { closePasswordCommonPopup, showPasswordCommonPopup } from 'store/password-store';
import BigNumber from 'bignumber.js';
import { useCountStore } from 'store/count-store';

export const useGacha = () => {
  const { getCnt } = useCountStore();
  const { password, setPassword } = useTempStore();
  const { getTokenList, updateInfo } = useMyInfo();
  const getDrawInfo = async () => {
    try {
      const { data } = await api.get<{ gachaPrice: string }>('/api/gacha/draw-info');
      return data.gachaPrice;
    } catch (error) {
      throw error;
    }
  };

  const gachaTransfrom = async (p: string, repeatCount: number): Promise<GachaItemType[]> => {
    try {
      const { data } = await api.post<GachaItemType[]>('/api/gacha/transform-draw', {
        signPass: p,
        repeatCount,
      });
      return data;
    } catch (error) {
      throw error;
    }
  };

  const gachaDoll = async (p: string, repeatCount: number): Promise<GachaItemType[]> => {
    try {
      const { data } = await api.post<GachaItemType[]>('/api/gacha/doll-draw', {
        signPass: p,
        repeatCount,
      });
      return data;
    } catch (error) {
      throw error;
    }
  };

  const canBuyItem = async (itemPrice: string, repeatCount: number): Promise<boolean> => {
    try {
      const tokenList = await getTokenList();
      const poeTokenAmount = tokenList.find((i) => i.symbol === 'PED')?.amount || '0';
      return compareDecimalNumbers(poeTokenAmount, itemPrice, repeatCount);
    } catch (error) {
      throw error;
    }
  };

  const getGachaDetail = async (id: number): Promise<GachaItemDetail | undefined> => {
    try {
      const { data } = await api.get<{ item: GachaItemDetail }>(`/api/gacha/detail/${id}`);
      return data.item;
    } catch (error) {
      throw error;
    }
  };

  const drowGacha = async (
    clickType: string,
    repeatCount: number,
    callback: (result: GachaItemType[]) => void,
  ) => {
    try {
      const itemPrice = await getDrawInfo();
      const canBuy = await canBuyItem(itemPrice, repeatCount);
      if (canBuy) {
        const price = new BigNumber(itemPrice).times(repeatCount);
        showDrowPopup({ password, clickType, price, repeatCount, callback });
      } else {
        showCommonPopup({ title: 'PED가 부족 합니다. \n PED를 충전해주세요. ', closeText: '닫기' });
      }
    } catch (e: any) {
      showCommonPopup({ title: e.response.data.message, closeText: '닫기' });
    }
  };

  const showDrowPopup = ({
    password,
    clickType,
    price,
    repeatCount,
    callback,
  }: {
    password: string;
    clickType: string;
    price: BigNumber;
    repeatCount: number;
    callback: (result: GachaItemType[]) => void;
  }) => {
    showCommonPopup({
      title: `${
        clickType === 'doll' ? '마법인형' : '변신 '
      } 뽑기를 진행 하시겠습니까? \n  Are you sure to play Gacha`,
      desc: '가격: ' + price.toFixed(3) + ' PED',
      closeText: '취소(N)',
      confirm: async () => {
        if (password) {
          await gacha(clickType, password, repeatCount, callback);
          closeCommonPopup();
        } else {
          closeCommonPopup();
          showPasswordCommonPopup({
            confirm: async (pass: string) => await gacha(clickType, pass, repeatCount, callback),
          });
        }
      },
      confirmText: '뽑기(Y)',
    });
  };

  const gacha = async (
    clickType: string,
    password: string,
    repeatCount: number,
    callback: (result: GachaItemType[]) => void,
  ) => {
    try {
      const result = await drowItems(clickType, password, repeatCount);
      callback(result);
    } catch (e: any) {
      showCommonPopup({ title: e.response.data.message, closeText: '닫기' });
    } finally {
      closePasswordCommonPopup();
      updateInfo();
      getCnt();
    }
  };

  const drowItems = async (clickType: string, p: string, repeatCount: number) => {
    let result: GachaItemType[] = [];
    if (clickType === 'doll') {
      result = await gachaDoll(p, repeatCount);
    } else {
      result = await gachaTransfrom(p, repeatCount);
    }
    setPassword(p);
    return result;
  };

  return {
    gachaTransfrom,
    gachaDoll,
    canBuyItem,
    getGachaDetail,
    getDrawInfo,
    drowGacha,
  };
};
