/// <reference types="vite/client" />
interface Window {
  AppleID: any;
}
