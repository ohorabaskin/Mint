import axios from 'axios';
import { baseApiUrl } from 'utils';
import store from '../store/user-store';
import useTempStore from 'store/temp-password-tore';
import { loadingEnd, loadingStart } from 'store/loading-store';

export const api = axios.create({
  baseURL: baseApiUrl,
  timeout: 5000,
  headers: {
    'Content-Type': 'application/json',
    'X-VALABLE-VERSION': '1',
  },
});

api.interceptors.request.use(
  (config) => {
    loadingStart();
    const Authorization = store.getState().Authentication;
    if (Authorization) {
      config.headers.Authorization = Authorization;
      return config;
    }
    return config;
  },
  (error) => Promise.reject(error),
);

api.interceptors.response.use(
  (response) => {
    loadingEnd();
    return response;
  },
  (error) => {
    loadingEnd();
    const storeVar = store.getState();
    const passwordVar = useTempStore.getState();
    if (error.response.data.statusCode === 401) {
      storeVar.removeToken();
      storeVar.removeUser();
      passwordVar.resetPassword();
    }
    return Promise.reject(error);
  },
);
