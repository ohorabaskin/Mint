import { ListItemType } from '@types';
import { useMint } from 'hook/useMint';
import { useState } from 'react';
import { convertGachaGradeText } from 'utils';
import { MintingDetailPopup } from './MintingDetailPopup';

export const MintingItem = ({ item }: { item: ListItemType }) => {
  const [showDetail, setShowDetail] = useState(false);
  const { minitnig } = useMint();
  return (
    <>
      <MintingDetailPopup
        id={item.id}
        visible={showDetail}
        close={() => {
          setShowDetail(false);
        }}
        tid={item.TID}
        canMint={item.GachaGrade > 2}
      />
      <div className="minting-item">
        <div
          onClick={() => {
            setShowDetail(true);
          }}
        >
          <img src={item.nftInfoMetaData.CardImagePath} alt="card-img" />
          <div className="minting-img-desc">
            <p className="title">{convertGachaGradeText(item.GachaGrade)}</p>
            <p className="desc">{item.nftInfoMetaData.Name}</p>
          </div>
        </div>

        <div
          className={`common-btn ${convertGachaGradeText(item.GachaGrade)}`}
          onClick={async () => {
            if (item.GachaGrade > 2) await minitnig(item.id);
          }}
        >
          <p>
            MINT
            {item.GachaGrade > 2 ? (
              <></>
            ) : (
              <>
                <br />
                Minting only rare grade or higher
              </>
            )}
          </p>
        </div>
      </div>
    </>
  );
};
