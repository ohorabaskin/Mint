import { Swiper, SwiperSlide } from 'swiper/react';
import SwiperCore, { Autoplay } from 'swiper';
import 'swiper/css';
SwiperCore.use([Autoplay]); // Swiper

export const VisualSlider = () => {
  return (
    <div className="swiper-container">
      <Swiper
        slidesPerView={1}
        loop={true}
        autoplay={true}
        centeredSlides={true}
        allowTouchMove={false}
      >
        <SwiperSlide>
          <img className="mobile" src="/img/visual-img/1-back.jpg" alt="" />
          <img className="web" src="/img/visual-img/1.jpg" alt="" />
        </SwiperSlide>
        <SwiperSlide>
          <img className="mobile" src="/img/visual-img/2-back.jpg" alt="" />
          <img className="web" src="/img/visual-img/2.jpg" alt="" />
        </SwiperSlide>
        <SwiperSlide>
          <img className="mobile" src="/img/visual-img/3-back.jpg" alt="" />
          <img className="web" src="/img/visual-img/3.jpg" alt="" />
        </SwiperSlide>
        <SwiperSlide>
          <img className="mobile" src="/img/visual-img/4-back.jpg" alt="" />
          <img className="web" src="/img/visual-img/4.jpg" alt="" />
        </SwiperSlide>
      </Swiper>
    </div>
  );
};
