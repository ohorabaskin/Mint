import { useGacha } from 'hook/useGacha';
import { CommonPopupLayout } from './CommonPopupLayout';
import { useState } from 'react';
import { GachaItemType } from '@types';
import { DrawerCard } from './DrawerCard';
import { ManyCardPopup } from './ManyCardPopup';
import { initImgList } from 'utils';
import { useListStore } from 'store/list-store';

export const DrowGacha = ({
  visible,
  close,
  clickType,
}: {
  visible: boolean;
  close: () => void;
  clickType: string;
}) => {
  const { reset } = useListStore();
  const { drowGacha } = useGacha();
  const [manyCnt, setManyCnt] = useState(0);
  const [manyCardVisible, setManyCardVisible] = useState(false);
  const [click, setClick] = useState(false);
  const [list, setList] = useState(initImgList);
  const resetPopup = () => {
    setClick(false);
    setList(initImgList);
    reset();
  };

  const callback = (result: GachaItemType[]) => {
    setList(result);
    reset();
    setClick(true);
  };

  if (!visible) return <></>;
  return (
    <>
      <ManyCardPopup
        manyCnt={manyCnt}
        visible={manyCardVisible}
        close={() => {
          setManyCardVisible(false);
          resetPopup();
          setClick(false);
        }}
        closeParentPopup={close}
        clickType={clickType}
      />
      <CommonPopupLayout style={{ zIndex: 98 }}>
        <div className="gacha-back">
          <div
            className="popup-close"
            onClick={() => {
              resetPopup();
              close();
            }}
          >
            <img src="/img/x-btn-white.svg" alt="" />
          </div>

          <div className={`card-wrap ${visible && 'init'}`}>
            {list.map((i, index) => (
              <DrawerCard key={'card-index' + index} i={i} index={index} click={click} />
            ))}
          </div>
        </div>
        <div className="gacha-button-container">
          <div
            className="gacha-button"
            onClick={() => {
              resetPopup();
              close();
            }}
          >
            <p>
              인벤토리 확인
              <br />
              <span>Check Inventory</span>
            </p>
          </div>
          <div
            className="gacha-button"
            onClick={async () => {
              setClick(false);
              await drowGacha(clickType, 1, callback);
            }}
          >
            <p>
              뽑기 진행하기
              <br />
              <span>Play Gacha</span>{' '}
            </p>
          </div>
        </div>

        <div className="gacha-button-container ten">
          <div
            className="gacha-button"
            onClick={async () => {
              setManyCnt(10);
              setManyCardVisible(true);
            }}
          >
            <p>Play x 10회</p>
          </div>
        </div>

        <div className="gacha-button-container fifty">
          <div
            className="gacha-button"
            onClick={async () => {
              setManyCnt(50);
              setManyCardVisible(true);
            }}
          >
            <p>Play x 50회 </p>
          </div>
        </div>
      </CommonPopupLayout>
    </>
  );
};
