export const Footer = () => {
  return (
    <>
      <footer>
        <div className="bottom-logo-container">
          <div className="logo" onClick={() => location.reload()}>
            <img src="/img/logo.svg" alt="" />
          </div>
          <p className="follow-text">Follow us</p>
          <ul className="sns-list">
            <li>
              <a href="https://medium.com/@itsblocofficial" target="_blank">
                <img src="/img/sns1.svg" alt="" />
              </a>
            </li>
            <li>
              <a href="https://discord.com/invite/itsblocofficial" target="_blank">
                <img src="/img/sns2.svg" alt="" />
              </a>
            </li>
            <li>
              <a href="https://twitter.com/itsblocofficial" target="_blank">
                <img src="/img/sns3.svg" alt="" />
              </a>
            </li>
            <li>
              <a href="https://t.me/itsblocofficial" target="_blank">
                <img src="/img/sns4.svg" alt="" />
              </a>
            </li>
          </ul>
        </div>
        <ul className="menu-list">
          <li>
            <a href="https://www.itsbloc.io">
              <p>Ecosystem</p>
            </a>
          </li>
          <li>
            <a href="mailto:contact@itsbloc.io">
              <p>Contact us ↘︎</p>
            </a>
          </li>
          <li>
            <a href="https://www.itsbloc.io/#faq" target="_blank">
              <p>FAQ ↘︎</p>
            </a>
          </li>
        </ul>
      </footer>
      <p className="copy-text">Copyright 2021 RAINFTB All Right Reserved</p>
    </>
  );
};
