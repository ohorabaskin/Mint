import { usePasswordStore } from 'store/password-store';
import { CommonPopupLayout } from './CommonPopupLayout';
import { useState } from 'react';

export const PasswordPopup = ({}: {}) => {
  const { visible, closePopup, confirm } = usePasswordStore();
  const [password, setPassword] = useState('');
  if (!visible) return <></>;
  return (
    <CommonPopupLayout style={{ zIndex: 100 }}>
      <div className="common-wrap">
        <div className="text-container">
          <p className={`title-text`}>
            비밀번호를 입력해주세요
            <br />
            Enter your password
          </p>
          <input
            value={password}
            type="password"
            className="common-input"
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <div className="popup-button-container">
          <div className="popup-button has-border" onClick={closePopup}>
            <p className="button-text">취소(N)</p>
          </div>
          <div
            className="popup-button"
            onClick={async () => {
              try {
                confirm && (await confirm(password));
                setPassword('');
              } catch (e) {
                setPassword('');
              }
            }}
          >
            <p className="button-text">확인(Y)</p>
          </div>
        </div>
      </div>
    </CommonPopupLayout>
  );
};
