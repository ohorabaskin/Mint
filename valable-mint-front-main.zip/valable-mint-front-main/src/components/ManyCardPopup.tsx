import { GachaItemType } from '@types';
import { CommonPopupLayout } from './CommonPopupLayout';
import { useEffect, useState } from 'react';
import { DrawerCard } from './DrawerCard';
import { useGacha } from 'hook/useGacha';
import { fillCard } from 'utils';

export const ManyCardPopup = ({
  visible,
  close,
  manyCnt,
  clickType,
  closeParentPopup,
}: {
  visible: boolean;
  close: () => void;
  manyCnt: number;
  clickType: string;
  closeParentPopup: () => void;
}) => {
  const { drowGacha } = useGacha();
  const [click, setClick] = useState(false);
  const [animationTime, setAnimationTime] = useState(0.2);
  const [readyList, setReadyList] = useState<GachaItemType[]>(fillCard(manyCnt));

  const reset = (value: number) => {
    setAnimationTime(0);
    setClick(false);
    setReadyList([]);
    setTimeout(() => {
      setReadyList(fillCard(value));
      setAnimationTime(0.2);
    }, 500);
  };

  const callback = (list: GachaItemType[]) => {
    setReadyList(list);
    setTimeout(() => {
      setClick(true);
    }, 500);
  };

  useEffect(() => {
    setReadyList(fillCard(manyCnt));
  }, [manyCnt]);

  useEffect(() => {
    const initGetList = async () => {
      setAnimationTime(0.2);
      await drowGacha(clickType, manyCnt, callback);
    };
    if (visible) {
      initGetList();
    }
  }, [visible]);

  if (visible)
    return (
      <CommonPopupLayout style={{ zIndex: 99 }}>
        <div className="gacha-back">
          <div
            className="popup-close"
            onClick={() => {
              setAnimationTime(0.2);
              close();
            }}
          >
            <img src="/img/x-btn-white.svg" alt="" />
          </div>
          <div className="many-card-inner">
            <div className="inner">
              {readyList.map((i, index) => {
                return (
                  <DrawerCard
                    key={'DrawerCard' + index}
                    i={i}
                    index={index}
                    click={click}
                    animationTime={animationTime}
                  />
                );
              })}
            </div>
          </div>
        </div>

        <div className="gacha-button-container one">
          <div
            className="gacha-button wi-200 check-inventory"
            onClick={() => {
              close();
              closeParentPopup();
            }}
          >
            <p>
              인벤토리 확인
              <br />
              <span>Check Inventory</span>
            </p>
          </div>

          <div
            className="gacha-button center spacer wi-200 first"
            onClick={async () => {
              reset(10);
              await drowGacha(clickType, 10, callback);
            }}
          >
            <p>Play x 10회</p>
          </div>

          <div
            className="gacha-button center wi-200 second"
            onClick={async () => {
              reset(50);
              await drowGacha(clickType, 50, callback);
            }}
          >
            <p>Play x 50회 </p>
          </div>

          <div className="gacha-button-container fast-container">
            <div
              className="gacha-button center wi-200"
              onClick={async () => {
                setAnimationTime(0);
              }}
            >
              <p>
                결과 빨리 보기
                <br /> Show all at once
              </p>
            </div>
          </div>
        </div>
      </CommonPopupLayout>
    );

  return <></>;
};
