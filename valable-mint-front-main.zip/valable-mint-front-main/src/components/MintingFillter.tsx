import { useState } from 'react';
import { useCountStore } from 'store/count-store';
import { GachaType, SortType, useListStore } from 'store/list-store';
import { convertSortText } from 'utils';

export const MintingFilter = () => {
  const { sortBy, setSortBy, gachaType, setGachaType, reset } = useListStore();
  const { count } = useCountStore();
  const [open, setOpen] = useState(false);

  return (
    <>
      <div className="top-filter">
        <div className="m-opensea-container">
          <a href="https://opensea.io/collection/itsbloc-dknft" target="_blank">
            <img src="/img/open-sea-m.png" alt="" />
          </a>
        </div>
        <h3>Inventory</h3>
        <div className="m-metamask-container">
          <a href="https://metamask.io/" target="_blank">
            <img src="/img/metamask-mobile.jpg" alt="" />
          </a>
        </div>
        <div className="filters">
          <div className={`sorting-menu ${open ? 'active' : ''}`} onClick={() => setOpen(!open)}>
            <p>{sortBy ? convertSortText(sortBy) : 'Default sorting'}</p>
            <div className="arr">
              <img src={'/img/arrow.svg'} />
            </div>
            {open && (
              <div className="open-menu">
                <ul>
                  <li
                    onClick={() => {
                      setSortBy(SortType.gradeAsc);
                      reset({ sort: SortType.gradeAsc, gacha: gachaType });
                    }}
                  >
                    등급 오름 차순
                  </li>
                  <li
                    onClick={() => {
                      setSortBy(SortType.gradeDesc);
                      reset({ sort: SortType.gradeDesc, gacha: gachaType });
                    }}
                  >
                    등급 내림 차순
                  </li>
                  <li
                    onClick={() => {
                      setSortBy(SortType.createdAtAsc);
                      reset({ sort: SortType.createdAtAsc, gacha: gachaType });
                    }}
                  >
                    시간별 오름 차순
                  </li>
                  <li
                    onClick={() => {
                      setSortBy(SortType.createdAtDesc);
                      reset({ sort: SortType.createdAtDesc, gacha: gachaType });
                    }}
                  >
                    시간별 내림 차순
                  </li>
                </ul>
              </div>
            )}
          </div>
        </div>
      </div>
      <div className="bottom-filter">
        <div className="filter-text-container">
          <p
            className={`${gachaType === GachaType.all && 'active'}`}
            onClick={() => {
              setGachaType(GachaType.all);
              reset({ gacha: GachaType.all, sort: sortBy });
            }}
          >
            ALL({(count[1].MagicDoll || 0) + (count[0].Transform || 0)})
          </p>
          <p
            className={`${gachaType === GachaType.Transform && 'active'}`}
            onClick={() => {
              setGachaType(GachaType.Transform);
              reset({ gacha: GachaType.Transform, sort: sortBy });
            }}
          >
            변신({count[0].Transform || 0})
          </p>
          <p
            className={`${gachaType === GachaType.MagicDoll && 'active'}`}
            onClick={() => {
              setGachaType(GachaType.MagicDoll);
              reset({ gacha: GachaType.MagicDoll, sort: sortBy });
            }}
          >
            마법인형({count[1].MagicDoll || 0})
          </p>
        </div>
      </div>
    </>
  );
};
