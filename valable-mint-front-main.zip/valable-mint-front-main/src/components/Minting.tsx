import { useListStore } from 'store/list-store';
import { MintingFilter } from './MintingFillter';
import { MintingItem } from './MintingItem';

export const Minting = () => {
  const { getList, list } = useListStore();

  return (
    <>
      <div className="minting-container">
        <MintingFilter />
        <div className="minting-item-container">
          {list.items.length === 0 && (
            <div className="empty">
              <p>아이템이 없습니다.</p>
            </div>
          )}
          {list.items.map((i) => {
            return <MintingItem key={i.id} item={i} />;
          })}
        </div>
      </div>

      {list.items.length !== 0 && (
        <div className="common-btn more" onClick={() => getList()}>
          <p>
            더보기
            <br />
            more
          </p>
        </div>
      )}
    </>
  );
};
