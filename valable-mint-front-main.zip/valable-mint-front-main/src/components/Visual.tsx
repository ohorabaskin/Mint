import { useState } from 'react';
import { DrowGacha } from './DrowGacha';
import { useSignHook } from 'hook/useSignHook';
import { showCommonPopup } from 'store/popup-store';
import { VisualSlider } from './VisualSlider';

export const Visual = () => {
  const [clickType, setClickType] = useState('');
  const [gachaPopup, setGachaPopup] = useState(false);
  const { loginType } = useSignHook();

  const showPopup = (type: string) => {
    if (!loginType) {
      showCommonPopup({ title: '로그인 이후 이용해주세요.', closeText: '닫기' });
    }
  };
  return (
    <>
      <DrowGacha visible={gachaPopup} close={() => setGachaPopup(false)} clickType={clickType} />
      <div className="visual-container">
        <div className="left-text">
          <p className="h2-desc">NFT STORE</p>
          <h2>
            <span className="web">
              Get your NFT hero and prepare for battle.
              <br />
              DK Mobile Genesis Season 3<br /> is coming soon.
            </span>
            <span className="mobile">
              Get your NFT hero and prepare for battle.
              <br />
              DK Mobile Genesis Season 3<br /> is coming soon.
            </span>
          </h2>
          <p className="give-text">
            <span className="web">
              We will give you 5 character cards by lottery once.
              <br />
              Rare grade cards or higher can be minted.
            </span>
            <span className="mobile">
              We will give you 5 character cards by lottery once.
              <br />
              Rare grade cards or higher can be minted.
            </span>
          </p>
          <div className="btn-container">
            <div
              className="common-btn disable wi-200"
              onClick={() => {
                showPopup('transform');
              }}
            >
              <p>
                변신 뽑기
                <br />
                <span>Transform</span>
              </p>
            </div>
            <div
              className="common-btn disable wi-200"
              onClick={() => {
                showPopup('doll');
              }}
            >
              <p>
                마법인형 뽑기
                <br />
                <span>Magic Doll</span>
              </p>
            </div>
          </div>
        </div>
        <div className="right-img">
          <VisualSlider />
        </div>

        <div className="opensea-container">
          <a href="https://opensea.io/collection/itsbloc-dknft" target="_blank">
            <img src="/img/open-sea.png" alt="" />
          </a>
        </div>

        <div className="metamask-container">
          <a href="https://metamask.io/" target="_blank">
            <img src="/img/metamask-web.png" alt="" />
          </a>
        </div>
      </div>
    </>
  );
};
