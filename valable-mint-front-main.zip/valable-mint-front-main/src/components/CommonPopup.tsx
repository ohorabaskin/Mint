import { closeCommonPopup, usePopupStore } from 'store/popup-store';
import { CommonPopupLayout } from './CommonPopupLayout';

export const CommonPopup = () => {
  const { info, visible } = usePopupStore();
  if (!visible) return <></>;
  return (
    <CommonPopupLayout>
      <div className="common-wrap">
        <div className="text-container">
          <p className={`title-text ${info.desc && 'hasDesc'}`}>{info.title}</p>
          <p className="desc-text">{info.desc}</p>
        </div>
        <div className="popup-button-container">
          <div
            className={`popup-button ${info.confirmText && 'has-border'}`}
            onClick={() => {
              closeCommonPopup();
              info.close && info.close();
            }}
          >
            <p className="button-text">{info.closeText}</p>
          </div>
          {info.confirmText && (
            <div className="popup-button" onClick={info.confirm}>
              <p className="button-text">{info.confirmText}</p>
            </div>
          )}
        </div>
      </div>
    </CommonPopupLayout>
  );
};
