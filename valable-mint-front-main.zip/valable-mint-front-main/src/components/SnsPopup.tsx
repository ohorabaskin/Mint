import { useSignHook } from 'hook/useSignHook';
import { CommonPopupLayout } from './CommonPopupLayout';
import SocialButton from './SocialButton';
import { useListStore } from 'store/list-store';
import { showCommonPopup } from 'store/popup-store';
import { useState } from 'react';
import { IntallPopup } from './IntallPopup';

export const SnsPopup = ({
  visible,
  close,
  getCnt,
}: {
  visible: boolean;
  close: () => void;
  getCnt: () => Promise<void>;
}) => {
  const [showInstall, setShowInstall] = useState(false);
  const { getList } = useListStore();
  const { snsLogin } = useSignHook();
  if (!visible) return <></>;

  const login = async (result: any, type: string) => {
    await snsLogin(result, type);
    getList(1);
    close();
    await getCnt();
  };

  return (
    <>
      <IntallPopup visible={showInstall} close={() => setShowInstall(false)} />
      <CommonPopupLayout>
        <div className="sns-popup-container">
          <div className="popup-close" onClick={close}>
            <img src="/img/x-btn-white.svg" alt="" />
          </div>
          <div className="sns-container">
            <div className="logo">
              <img src="/img/logo.svg" alt="" />
            </div>
            <ul>
              <li>
                <SocialButton
                  provider="google"
                  appId="518615577048-2c5ivcsmg3lucg5ud46vr9kpl1i505v4.apps.googleusercontent.com"
                  onLoginSuccess={async (result) => {
                    await login(result, 'google');
                  }}
                >
                  <p>Continue with google</p>
                </SocialButton>
              </li>
              {/* <LoginWithApple /> */}

              <li>
                <SocialButton
                  provider="facebook"
                  appId="1360975747715295"
                  onLoginSuccess={async (result) => {
                    await login(result, 'facebook');
                  }}
                >
                  <p>Continue with Facebook</p>
                </SocialButton>
              </li>
            </ul>

            <p
              className="account-text"
              onClick={() => {
                setShowInstall(true);
              }}
            >
              Don’t have account?
            </p>
          </div>
        </div>
      </CommonPopupLayout>
    </>
  );
};
