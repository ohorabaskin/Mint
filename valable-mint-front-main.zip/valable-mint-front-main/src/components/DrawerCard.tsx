import { GachaItemType } from '@types';
import { useEffect, useState } from 'react';
export const DrawerCard = ({
  click,
  index,
  i,
  animationTime = 0.2,
}: {
  i: GachaItemType;
  index: number;
  click: boolean;
  animationTime?: number;
}) => {
  const [time, setTime] = useState(index * animationTime);
  useEffect(() => {
    setTime(animationTime * index);
  }, [animationTime]);

  if (i.CardImagePath && animationTime === 0) {
    return <img className={`card-img card-back`} src={i.CardImagePath} alt="" />;
  }
  return (
    <div
      className={`card ${click && 'active'}`}
      key={index + 'card'}
      style={{
        transitionDelay: `${time}s`,
        transitionDuration: `${animationTime === 0 ? 0 : 0.5}s`,
      }}
    >
      <img className={`card-img card-front`} src="/img/card.svg" alt="" />
      <img
        style={{
          transitionDelay: `${time}s`,
        }}
        className={`card-img card-back ${animationTime === 0 ? 'show-now' : ''}`}
        src={i.CardImagePath}
        alt=""
      />
      {click && (
        <div style={{ animationDelay: `${time}s` }} className={`card-ani ${i.Grade}`}></div>
      )}
    </div>
  );
};
