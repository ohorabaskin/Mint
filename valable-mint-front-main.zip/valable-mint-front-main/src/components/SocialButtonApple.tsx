import AppleLogin from 'react-apple-login';
import React from 'react';

export default class LoginWithApple extends React.Component {
  render() {
    return (
      <AppleLogin
        clientId={'io.itsbloc.wallet.serviceid'}
        redirectURI={'https://home-dev.itsbloc.com'}
        responseType={'code'}
        responseMode={'query'}
        usePopup={false}
        render={(renderProps) => {
          return (
            <li onClick={renderProps.onClick}>
              <p>Continue with Apple</p>
            </li>
          );
        }}
      />
    );
  }
}
