import { PropsWithChildren } from "react";

interface ModalDefaultType {
  onClickToggleModal: () => void;
}

function Modal({
  onClickToggleModal,
  children,
}: PropsWithChildren<ModalDefaultType>) {
  
  return (
    <div className="modal-container">
      <div className="dialog-box">
        <h2>Notice</h2>
        <div className="close-box"
            onClick={e => {
              e.preventDefault();

              if (onClickToggleModal) {
                onClickToggleModal();
              }
            }}
          >
            <img src="/img/close.png" alt="" />
        </div>
        <img src="/img/season_close.jpeg" alt="" /><br/><br/>
        {children}
      </div>
      <div className="backdrop"
        onClick={e => {
          e.preventDefault();

          if (onClickToggleModal) {
            onClickToggleModal();
          }
        }}
      />
    </div>
  );
}

export default Modal;
