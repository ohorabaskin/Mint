import { closeCommonPopup, usePopupStore } from 'store/popup-store';
import { CommonPopupLayout } from './CommonPopupLayout';

interface Props {
  visible: boolean;
  close: () => void;
}

export const IntallPopup = ({ visible, close }: Props) => {
  if (visible)
    return (
      <CommonPopupLayout style={{ zIndex: 102 }}>
        <div className="common-wrap">
          <div className="text-container por">
            <div className="popup-close" onClick={close}>
              <img className="small" src="/img/x-btn-white.svg" alt="" />
            </div>
            <p className={`title-text`}>You must install the app!</p>
          </div>
          <div className="btn-row">
            <div className={`sign-in-btn `}>
              <a
                href="https://play.google.com/store/apps/details?id=io.itsbloc.wallet&hl=ko"
                target="_blank"
              >
                <p className="button-text">Android</p>
              </a>
            </div>
            <div className="sign-in-btn">
              <a href="https://apps.apple.com/kr/app/itsbloc/id1632866346" target="_blank">
                <p className="button-text">IOS</p>
              </a>
            </div>
          </div>
        </div>
      </CommonPopupLayout>
    );

  return <></>;
};
