import { GachaItemDetail } from '@types';
import { CommonPopupLayout } from './CommonPopupLayout';
import { useEffect, useState } from 'react';
import { useGacha } from 'hook/useGacha';
import { Loading } from './Loading';
import { useMint } from 'hook/useMint';

export const MintingDetailPopup = ({
  visible,
  close,
  id,
  tid,
  canMint,
}: {
  id: number;
  visible: boolean;
  close: () => void;
  tid: number;
  canMint: boolean;
}) => {
  const { minitnig } = useMint();
  const [item, setItem] = useState<GachaItemDetail>();
  const { getGachaDetail } = useGacha();

  useEffect(() => {
    const getItem = async () => {
      const data = await getGachaDetail(id);
      setItem(data);
    };
    visible && getItem();
  }, [id, visible, tid]);

  const closePopup = () => {
    close();
  };

  if (!visible) return <></>;
  if (!item) return <Loading />;
  return (
    <CommonPopupLayout style={{ zIndex: 10 }} dimClick={closePopup}>
      <div className="detail-wrap">
        <div className="popup-close" onClick={closePopup}>
          <img src="/img/x-btn-white.svg" alt="" />
        </div>

        <div className="detail-img">
          <img src={item.ImagePath} alt="" />
        </div>
        <p className="title">
          {item.Name}, {item.Grade}
        </p>

        {item.Attribute1Name !== '0' && (
          <div className="row">
            <p className="attr">{item.Attribute1Name}</p>
            <p className="attr">{item.Attribute1Value}</p>
          </div>
        )}

        {item.Attribute2Name !== '0' && (
          <div className="row">
            <p className="attr">{item.Attribute2Name}</p>
            <p className="attr">{item.Attribute2Value}</p>
          </div>
        )}
        {item.Attribute3Name !== '0' && (
          <div className="row">
            <p className="attr">{item.Attribute3Name}</p>
            <p className="attr">{item.Attribute3Value}</p>
          </div>
        )}
        {item.Attribute4Name !== '0' && (
          <div className="row">
            <p className="attr">{item.Attribute4Name}</p>
            <p className="attr">{item.Attribute4Value}</p>
          </div>
        )}
        {item.Attribute5Name !== '0' && (
          <div className="row">
            <p className="attr">{item.Attribute5Name}</p>
            <p className="attr">{item.Attribute5Value}</p>
          </div>
        )}
        {item.Attribute6Name !== '0' && (
          <div className="row">
            <p className="attr">{item.Attribute6Name}</p>
            <p className="attr">{item.Attribute6Value}</p>
          </div>
        )}

        <div className="detail-button-container">
          <div
            style={{ opacity: canMint ? 1 : 0.3 }}
            className="common-btn"
            onClick={async () => (canMint ? await minitnig(id, closePopup) : null)}
          >
            <p>
              MINT
              {canMint ? (
                <></>
              ) : (
                <span className="small">
                  <br />
                  Minting only rare grade or higher
                </span>
              )}
            </p>
          </div>
          <div className="black-button" onClick={closePopup}>
            <p className="button-text">인벤토리</p>
          </div>
        </div>
      </div>
    </CommonPopupLayout>
  );
};
