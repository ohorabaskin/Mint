import { useSignHook } from 'hook/useSignHook';
import { CommonPopupLayout } from './CommonPopupLayout';
import useMyInfo from 'hook/useMyInfo';
import { closeCommonPopup, showCommonPopup } from 'store/popup-store';

export const LogoutPopup = ({
  visible,
  close,
  reset,
  resetCnt,
}: {
  visible: boolean;
  close: () => void;
  reset: () => void;
  resetCnt: () => void;
}) => {
  const { user } = useMyInfo();
  const { logout } = useSignHook();
  if (!visible) return <></>;

  return (
    <>
      <CommonPopupLayout style={{ zIndex: 70 }}>
        <div className="sns-popup-container type2">
          <div className="popup-close" onClick={close}>
            <img src="/img/x-btn-white.svg" alt="" />
          </div>
          <div className="sns-container">
            <p className="sns-title">Connected with ITSBLOC</p>
            <p className="sns-title">{user.nickName}</p>
            <div className="address-container">
              <p className="address-text">{user.walletAccount}</p>
              {/* <CopyToClipboard
                text={user.walletAccount}
                onCopy={() => alert('주소가 복사 되었습니다.')}
              >
                <span className="copy-address-text">Copy Address</span>
              </CopyToClipboard> */}
            </div>
            <div
              className="disconnect-text-container"
              onClick={() => {
                showCommonPopup({
                  title: '로그아웃 하시겠습니까?',
                  closeText: '취소',
                  confirmText: '확인',
                  confirm: () => {
                    logout();
                    reset();
                    close();
                    resetCnt();
                    closeCommonPopup();
                  },
                });
              }}
            >
              <img src="/img/logout.png" alt="logout" />
              <p className="disconnect-text">Disconnect</p>
            </div>
          </div>
        </div>
      </CommonPopupLayout>
    </>
  );
};
