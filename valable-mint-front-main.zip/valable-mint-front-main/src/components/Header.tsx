import { useEffect, useState } from 'react';
import { SnsPopup } from './SnsPopup';
import useMyInfo from 'hook/useMyInfo';
import { priceParse } from 'utils';
import { LogoutPopup } from './LogoutPopup';
import { useCountStore } from 'store/count-store';
import { useListStore } from 'store/list-store';

export const Header = () => {
  const { getCnt, resetCnt } = useCountStore();
  const { reset, getList } = useListStore();
  const [visible, setVisible] = useState(false);
  const [logoutVisible, setLogoutVisible] = useState(false);
  const { user } = useMyInfo();

  useEffect(() => {
    if (user.loginType) {
      getList(1);
      getCnt();
    }
  }, []);

  return (
    <>
      <SnsPopup visible={visible} close={() => setVisible(false)} getCnt={getCnt} />
      <LogoutPopup
        visible={logoutVisible}
        close={() => setLogoutVisible(false)}
        reset={reset}
        resetCnt={resetCnt}
      />
      <header>
        <div className="inner">
          <h1 className="logo" onClick={() => location.reload()}>
            <img src={'/img/logo.svg'} alt="logo" />
          </h1>

          {user.loginType ? (
            <div className="right-item">
              <div className="token-wrapper">
                {user.tokenList
                  .filter((i) => i.symbol === 'PED' || i.symbol === 'MATIC')
                  .map((token) => {
                    return (
                      <div className="token-container" key={token.name}>
                        <div className="img-container">
                          <img src={token.symbolUrl} alt="" />
                        </div>
                        <p>{priceParse(token.amount)}</p>
                      </div>
                    );
                  })}
              </div>
              <div
                className="profile"
                onClick={() => {
                  setLogoutVisible(true);
                }}
              >
                <p>{user.nickName.toUpperCase().charAt(0)}</p>
              </div>
            </div>
          ) : (
            <>
              <div className="sign-in-btn" onClick={() => setVisible(true)}>
                <p>Login</p>
              </div>
            </>
          )}
        </div>
      </header>
    </>
  );
};
