import { CSSProperties } from 'react';

export const CommonPopupLayout = ({
  children,
  style,
  dimClick,
}: {
  children: React.ReactNode | React.ReactElement[];
  style?: CSSProperties;
  dimClick?: () => void;
}) => {
  return (
    <div
      className="modal-wrapper"
      style={style}
      onClick={(e: any) => {
        if (e.target.className === 'modal-container') dimClick ? dimClick() : undefined;
      }}
    >
      <div className="dim"></div>
      <div className="modal-container">{children}</div>
    </div>
  );
};
