import { useLoadingStore } from 'store/loading-store';

export const Loading = () => {
  const { loading } = useLoadingStore();
  if (loading)
    return (
      <div className="loading-container">
        <div className="dim" />
        <img src="/img/loading.gif" alt="" />
      </div>
    );
  return <></>;
};
